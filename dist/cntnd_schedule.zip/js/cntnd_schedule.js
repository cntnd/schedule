/* cntnd_schedule */
